This is "Corvus Tano" - an Ahsoka Tano CFX and Proffie sound font based on her first live-action appearance on the planet Corvus in The Mandalorian Season 2, Episode 5 (Chapter 13) called "The Jedi". 
This font was partly put together by me, Ninja Jedi Order (previously known as Star Wars Haven), for free for Ahsoka fans and Star Wars fans alike to enjoy.
                                                   
https://www.youtube.com/watch?v=Rzs-HqBXTB4&ab_channel=NinjaJediOrder