The Sabre hum features a slave1 engine-idle sound taken from a game. The bass-end was cut and replaced with the deep ambient bass-rumble of a star-ship, and in the top-end the hiss/whine of an F22 fighter was added to ensure copyright adherance and to tie-in with your aero connection. 

Swings were reworked from film footage featuring slave1 (in particular, Jango's dog-fight vs Obi-Wan)


Clashes are variously from Slave1's cannons, Boba-Fett and Jango-Fet blaster noises, layered with jet-pack and electric crackling. 

Power on and off are reworked samples of the jet pack

combos are variations of seismic charge


lockup is a melange of fighter craft whine (in crash) electricity, turbulence and hum. 

https://www.fx-sabers.com/forum/index.php?topic=50054.msg641926