ARCANE

This font is what I imagine a saber used by a powerful Sith Sorcerer would sound like

Created by TehMothman

https://www.reddit.com/r/lightsabers/comments/gcl09r/just_made_some_free_soundfonts_for_you_all_to/